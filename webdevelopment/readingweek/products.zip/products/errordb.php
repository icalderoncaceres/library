<?php
	$arr = $stmt->errorInfo();
	if (isset($arr[2])) {// we have an error 
	  echo "<br/> Database Error: ".$arr[2];
	  exit();
	}	
?>

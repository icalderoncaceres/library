<?php
include('header.php');
include('db.php'); //note we moved this line
$product = "";
$product_desc = "";  
$cost = 0.00;
if ($_POST) {
 	$product = $_POST['product'];
	$product_desc = $_POST['description'];  
	$cost = $_POST['cost'];
    $stmt = $DBH->prepare("INSERT into Products 
					(product_name,product_description,cost) 			
					Values(:product,:pd,:cost)");
	$stmt->bindValue(':pd', $product_desc);
	$stmt->bindValue(':product', $product);
	$stmt->bindValue(':cost', $cost);
	$stmt->execute();
    include('errordb.php'); 
	header("Location: products.php");
}
?>
<h2>Create Product</h2><br></br>   
<form class='form-style' action="createProduct.php" method="post">  
Product: <input type="text" name="product" value="<?php echo $product; ?>" />
Description: <input type="text" name="description" value="<?php echo $product_desc; ?>" />
Cost: <input type="text" name="cost" value="<?php echo $cost; ?>" />
<input type="submit" name="submit" value="Save" class='button'/>
</form>
<?php include('footer.php'); ?>


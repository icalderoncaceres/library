
<?php
include('header.php');
include('db.php'); //note we moved this line

if ($_GET){
	$pid = $_GET['id'];  // from link in products.php
	include('db.php');
	$stmt = $DBH->prepare("SELECT * FROM Products WHERE id= :pid");
	$stmt->bindValue(':pid', $pid);
	$stmt->execute();
	include('errordb.php'); 
	$row = $stmt->fetch(PDO::FETCH_ASSOC);
	$product = $row['product_name'];
	$product_desc = $row['product_description'];  
	$cost = $row['cost'];
}
if ($_POST) {
    $pid = $_POST['pid']; // from hidden input field
	$product = $_POST['product'];
	$product_desc = $_POST['description'];  
	$cost = $_POST['cost'];

	$stmt = $DBH->prepare(
"UPDATE Products set product_name = :product,
				product_description = :pd,
				cost = :cost
				WHERE id = :pid");
	$stmt->bindValue(':pid', $pid);
	$stmt->bindValue(':pd', $product_desc);
	$stmt->bindValue(':product', $product);
	$stmt->bindValue(':cost', $cost);

	$stmt->execute();
    include('errordb.php'); 
	header("Location: products.php");
}
?>
<h2>Update Product</h2><br></br>   
<form class='form-style' action="updateProduct.php" method="post">  
Product: <input type="text" name="product" value="<?php echo $product; ?>" />
Description: <input type="text" name="description" value="<?php echo $product_desc; ?>" />
Cost: <input type="text" name="cost" value="<?php echo $cost; ?>" />
<input type="hidden" name="pid" value="<?php echo $pid; ?>" />
<input type="submit" name="submit" value="Update" class='button'/>
</form>
<?php include('footer.php'); ?>


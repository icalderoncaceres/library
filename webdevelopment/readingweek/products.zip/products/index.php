<?php
  include('header.php');
?>
<h1> Welcome to our Products App</h1>
<?php
  include('footer.php');
?>  
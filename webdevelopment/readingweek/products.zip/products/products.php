<?php include('header.php'); ?>
<h2>Products List</h2>
<?php
// create the connection
  include('db.php');
// select the correct table
$stmt = $DBH->prepare("SELECT * FROM Products");
$stmt->execute();
include('errordb.php');
// get the rows and put it in a variable
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo "<table>";
echo "<tr><th>Id</th><th>Name</th><th>Description</th></tr>";
 foreach($rows as $row){
    echo "<tr>";
	echo "<td>";
	echo $row['id'];
	echo "</td>";
	echo "<td>";
	echo $row['product_name'];
	echo "</td>";
	echo "<td>";
	echo $row['product_description'];
	echo "</td>";
	echo "<td>";
	echo "<a href=viewProduct.php?id=".$row['id'].">View</a>";
	echo "</td>";
	echo "<td>";
	echo "<a href=deleteProduct.php?id=".$row['id'].">Delete</a>";
	echo "</td>";
	echo "<td>";
	echo "<a href=updateProduct.php?id=".$row['id'].">Edit</a>";
	echo "</td>";
	echo "</tr>";
}
echo "</table>";
?>
<?php include 'footer.php'; ?>

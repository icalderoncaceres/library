<?php include('header.php'); ?>
<h2>View Product</h2>

<?php
$pid = $_GET['id'];  
include('db.php');
$stmt = $DBH->prepare("SELECT * FROM Products WHERE id= :pid");
$stmt->bindValue(':pid', $pid);
$stmt->execute();
include('errordb.php'); 
$row = $stmt->fetch(PDO::FETCH_ASSOC);
echo $row['id'].", ".$row['product_name'].", ".$row['product_description'];  echo ", ".$row['cost']."<br/>";
?>
<?php include 'footer.php'; ?>


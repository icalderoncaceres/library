<div id='footer' >
  <br/><br/>&copy; CCT College 2017
</div>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
</head>
<body>
<link rel="stylesheet" href="menu.css">
<link rel="stylesheet" href="style.css">
<ul>
  <li><a href="index.php">Home</a></li>
  <li><a href="createProduct.php">New</a></li>
  <li><a href="products.php">List</a></li>
  <li><a href="#about">About</a></li>
</ul>

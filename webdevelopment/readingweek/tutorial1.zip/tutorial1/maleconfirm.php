<?php
    session_start();

	echo "<br/> gender is ".$_SESSION['gender'];
	echo "<br/> user is ".$_SESSION['username']

?>
<!DOCTYPE html>
<html>
<head></head>
<body>
<h1>You are in the male confirm file</h1>
</body>
</html>

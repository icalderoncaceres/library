<?php
    session_start();
	$usernameErr = "";
	$genderErr = "";
	if ($_POST) {
		$username = $_POST['username'];
		if (!isset($_POST['gender']))
			$genderErr = "Please select a gender";
		else	
			$gender = $_POST['gender'];
		if (strlen($username) <4 || strlen($username) > 20)
			$usernameErr = "name must be between 4 and 20 characters";
		if (empty($usernameErr) and empty($genderErr)) {
			$_SESSION['gender'] = $gender;
			$_SESSION['username'] = $username; 
			if ($gender == 'Male')
				header('location: maleconfirm.php');
			if ($gender == 'Female')
				header('location: femaleconfirm.php');
		}
	}		
?>
<!DOCTYPE html>
<html>
<head></head>
<body>
<form  action="form.php" method="POST">
First Name<input type='text' name='username' ></input>
<span><?php echo $usernameErr ?></span><br/><br/>
<input type='radio' name='gender' value='Male'>Male</input>
<input type='radio' name='gender' value='Female'>Female</input>
<span><?php echo $genderErr ?></span><br/><br/><br/>
<input type='submit' </input>
</form>
</body>
</html>
